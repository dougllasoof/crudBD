package usuario;

public enum SexoPessoa {
	MASCULINO,
	FEMININO,
	NAO_INFORMADO;

}
